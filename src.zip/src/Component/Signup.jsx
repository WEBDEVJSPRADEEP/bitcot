import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";
export default function Signup() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");

  function emailHandle(e) {
    setEmail(e.target.value);
    setEmailError(false);
  }
  function passHandle(e) {
    setPassword(e.target.value);
    setPasswordError(false);
  }

  function submitHandle(e) {
    e.preventDefault();

    if (email === "") {
      setEmailError(alert("please enter email"));
    } else if (!email.includes("@gmail.com")) {
      setEmailError(alert("please enter a valid email"));
    } else if (password === "") {
      setPasswordError(true);
    } else {
      let data = {
        email: email,
        password: password,
      };
      window.localStorage.setItem("item", JSON.stringify(data));
      alert("signup success");
      setEmail("");
      setPassword("");
      navigate("./login");
    }
  }
  return (
    <>
      <div className="container">
        <div className="middle">
          <h1 style={{ fontSize: "45px" }}>
            bit
            <span style={{ color: "rgb(67, 105, 216)", fontSize: "45px" }}>
              cot
            </span>
          </h1>
          <p style={{ fontSize: "11px" }}>Solving Digital Challenges</p>
          <p className="note">
            Already have an account
            <span style={{ color: "rgb(24, 72, 214" }}> Log-up</span>
          </p>

          <p style={{ marginLeft: "-155px" }}>
            <span style={{ color: "red" }}>*</span> Email
          </p>
          <input
            className="input"
            type="email"
            name="email"
            value={email}
            onChange={emailHandle}
          />
          {emailError ? <span>{emailError}</span> : ""}
          <p style={{ marginLeft: "-125px" }}>
            {" "}
            <span style={{ color: "red" }}>*</span> Password
          </p>
          <input
            className="input"
            type="password"
            name="password"
            value={password}
            onChange={passHandle}
          />
          {passwordError ? alert("please enter password") : ""}
          <button className="btn" onClick={submitHandle}>
            Sign-up
          </button>
        </div>
      </div>
    </>
  );
}
