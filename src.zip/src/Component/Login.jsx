import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";
export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [cPassword, setCPassword] = useState("");
  const [cPasswordError, setCPasswordError] = useState("");

  function emailHandle(e) {
    setEmail(e.target.value);
    setEmailError(false);
  }
  function passHandle(e) {
    setPassword(e.target.value);
    setPasswordError(false);
  }
  function cPassHandle(e) {
    setCPassword(e.target.value);
    setPasswordError(false);
  }

  function submitHandle(e) {
    e.preventDefault();

    if (email === "") {
      setEmailError(alert("please enter email"));
    } else if (!email.includes("@gmail.com")) {
      setEmailError(alert("please enter a valid email"));
    } else if (password === "") {
      setPasswordError(true);
    } else if (cPassword === "") {
      setCPasswordError(alert("Re-enter password"));
    } else if (password !== cPassword) {
      setCPasswordError(alert("password not match"));
    } else {
      let obj = window.localStorage.getItem("item");
      let data = JSON.parse(obj);
      console.log(obj);
      if (data?.email === email && data?.password === password) {
        alert("Log-in success");
        setEmail("");
        setPassword("");
        setCPassword("");
        navigate("/Product");
      } else {
        alert("something went wrong");
      }
    }
  }
  return (
    <>
      <div className="container">
        <div className="logMiddle">
          <h1 style={{ fontSize: "45px" }}>
            bit
            <span style={{ color: "rgb(67, 105, 216)", fontSize: "45px" }}>
              cot
            </span>
          </h1>
          <p style={{ fontSize: "11px" }}>Solving Digital Challenges</p>
          <p className="note">
            Already have an account
            <span style={{ color: "rgb(24, 72, 214" }}> Log-in</span>
          </p>

          <p style={{ marginLeft: "-155px" }}>
            <span style={{ color: "red" }}>*</span> Email
          </p>
          <input
            className="input"
            type="email"
            name="email"
            value={email}
            onChange={emailHandle}
          />
          {emailError ? <span>{emailError}</span> : ""}
          <p style={{ marginLeft: "-125px" }}>
            {" "}
            <span style={{ color: "red" }}>*</span> Password
          </p>
          <input
            className="input"
            type="password"
            name="password"
            value={password}
            onChange={passHandle}
          />
          {passwordError ? alert("please enter password") : ""}
          <p style={{ marginLeft: "-70px" }}>
            {" "}
            <span style={{ color: "red" }}>*</span> Confirm Password
          </p>
          <input
            className="input"
            type="Password"
            name="cPassword"
            value={cPassword}
            onChange={cPassHandle}
          />
          {cPasswordError ? <span>{cPasswordError}</span> : ""}
          <button className="btn" onClick={submitHandle}>
            Log-in
          </button>
        </div>
      </div>
    </>
  );
}
