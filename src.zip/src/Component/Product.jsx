import React, { useEffect, useState } from "react";

export default function Product() {
  const [data, setData] = useState([]);
  const [masterData, setMasterData] = useState([]);
  const [loader, setLoader] = useState(false);

  useEffect(() => {
    setLoader(true);
    setTimeout(() => {
      //   pick-up the fake api on google
      fetch("https://fakestoreapi.com/products", {
        method: "GET",
        body: null,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (data) {
          //   console.log(data);
          setData(data);
          setMasterData(data);
        })
        .catch((error) => {
          console.log(JSON.stringify(error), "error");
          alert("something went wrong");
        })
        .finally(() => {
          setLoader(false);
        });
    }, 1000);
  }, []);
  const ShowData = (curVal) => {
    if (curVal !== "All") {
      const upDatData = masterData.filter((item) => {
        return item.category === curVal;
      });
      console.log(upDatData);
      setData(upDatData);
    } else {
      setData(masterData);
    }
  };
  return (
    <>
      {loader === true ? (
        <div className="loader">
          <span></span>
        </div>
      ) : (
        <>
          <div className="heading">
            <h1 style={{ fontWeight: "bold" }}>Product List</h1>
            <button className="tabBtn" onClick={() => ShowData("All")}>
              All
            </button>
            <button
              className="tabBtn"
              onClick={() => ShowData("men's clothing")}
            >
              Man
            </button>
            <button
              className="tabBtn"
              onClick={() => ShowData("women's clothing")}
            >
              Woman
            </button>
            <button className="tabBtn" onClick={() => ShowData("electronics")}>
              Electronics
            </button>
            <button className="tabBtn" onClick={() => ShowData("jewelery")}>
              jewellery
            </button>
          </div>
          <div className="container-fluid">
            <div className="row">
              <div className="main-div">
                <div className=" col-lg-12 col-md-12 col-sm-12 col-12 card-data">
                  {data.map((item, i) => {
                    return (
                      <>
                        <div className="card-d" key={i}>
                          {
                            <img
                              className="itemImage"
                              src={item.image}
                              alt=""
                              height={160}
                              width={190}
                            />
                          }
                          <br />
                          <h6>{item.category}</h6>
                          <h6>{item.title}</h6>
                          <h5>
                            <b>Price- $ </b>
                            {item.price}
                          </h5>

                          <h6>
                            <b>Rating - </b>
                            {item.rating.rate}
                          </h6>
                          {<button className="button">Add to cart</button>}
                          <button className="button">Buy Now</button>
                        </div>
                      </>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
